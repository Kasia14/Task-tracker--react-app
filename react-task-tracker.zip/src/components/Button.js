import React from 'react'
import PropTypes from 'prop-types';

const Button = ({color, text, buttonHandler}) => {
    
 
    
    return (
        <div>
           <button onClick= {buttonHandler} style={{backgroundColor: color}} className='btn'>{text}</button> 
        </div>
    )
}

Button.defaultProps = {
    color: 'steelblue'
}

Button.propTypes = {
    text: PropTypes.string,
    color: PropTypes.string,
    buttonHandler: PropTypes.func

}
export default Button
